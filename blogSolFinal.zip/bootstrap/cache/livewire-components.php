<?php return array (
  'post-index' => 'App\\Http\\Livewire\\PostIndex',
  'servicio-index' => 'App\\Http\\Livewire\\ServicioIndex',
);
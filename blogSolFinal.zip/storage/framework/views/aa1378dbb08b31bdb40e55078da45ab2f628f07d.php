

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">
    <h1 class="tart">Listado de servicios</h1>
</div>

<div class="container mt-2 ">
    <a href="<?php echo e(route('administracion.servicios.create' )); ?>" class="btn btn-success shadow">Crear servicio</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('servicio-index')->html();
} elseif ($_instance->childHasBeenRendered('JYokilF')) {
    $componentId = $_instance->getRenderedChildComponentId('JYokilF');
    $componentTag = $_instance->getRenderedChildComponentTagName('JYokilF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JYokilF');
} else {
    $response = \Livewire\Livewire::mount('servicio-index');
    $html = $response->html();
    $_instance->logRenderedChild('JYokilF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sofia\Documents\fer\backup\xamp\blogSol\resources\views/admin/servicios/index.blade.php ENDPATH**/ ?>
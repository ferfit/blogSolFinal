

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
        <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>


    <div class="container mt-5 py-3">

       


        <div class="col-12 col-lg-10 mx-auto bg-white shadow py-2 px-5 rounded">

            <h2 class="text-center mt-3">Editar publicación</h2>

            <form method="POST" action="<?php echo e(route('administracion.posts.update',$post)); ?>" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mt-4">
                    <p>Imagen actual:</p>
                    <img src="/storage/<?php echo e($post->imagen); ?>" style="width:300px"alt="">
                </div>

                <div class="form-group mt-3">
                    <label for="imagen">Elige una imagén</label>
                    <input type="file" id="imagen" name="imagen" class="form-control <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-5 mx-2">
                    <label for="titulo">Título </label>
                    <input type="text" 
                    name="titulo" 
                    class="form-control <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="titulo"
                        value="<?php echo e($post->titulo); ?>">
                    <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="form-group">
                    <label for="contenido">Contenido</label>
                    <br>
                    <textarea name="contenido" id="contenido" cols="30" rows="10"
                    
                    ><?php echo e($post->contenido); ?></textarea>
                    <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               

                
                
                
                <div class="form-group my-5 mx-2">
                    <label for="titulo_en">Título en ingles</label>
                    <input type="text" 
                    name="titulo_en" 
                    class="form-control <?php $__errorArgs = ['titulo_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="titulo_en"
                    value="<?php echo e($post->titulo_en); ?>">
                    <?php $__errorArgs = ['titulo_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <div class="form-group">
                    <label for="contenido_en">Contenido en ingles</label>
                    <br>
                    <textarea name="contenido_en" id="contenido_en" cols="30" rows="10">
                        <?php echo e($post->contenido_en); ?>

                    </textarea>
                    <?php $__errorArgs = ['contenido_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group my-5 mx-2">
                    <label for="titulo_it">Título en italiano</label>
                    <input type="text" 
                    name="titulo_it" 
                    class="form-control <?php $__errorArgs = ['titulo_it'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="titulo_it"
                    value="<?php echo e($post->titulo_it); ?>">
                    <?php $__errorArgs = ['titulo_it'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <div class="form-group">
                    <label for="contenido_it">Contenido en italiano</label>
                    <br>
                    <textarea name="contenido_it" id="contenido_it" cols="30" rows="10">
                        <?php echo e($post->contenido_it); ?>

                    </textarea>
                    <?php $__errorArgs = ['contenido_it'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success shadow rounded" value="Actualizar publicación">
                </div>


            </form>
        </div>

    </div>

    <script>
        CKEDITOR.replace( 'contenido' );
    </script>
    <script>
        CKEDITOR.replace( 'contenido_en' );
    </script>
    <script>
        CKEDITOR.replace( 'contenido_it' );
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogSol\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>
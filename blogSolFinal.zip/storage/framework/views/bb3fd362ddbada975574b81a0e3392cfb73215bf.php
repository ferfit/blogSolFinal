

<?php $__env->startSection('content'); ?>



<section class="terapias terapias--terapias mt-5">
  <div class="container">

    <img src="/storage/<?php echo e($post->imagen); ?>" class="rounded shadow img-fluid ">
    <h2 class="mt-5"><?php echo e($post->titulo_it); ?></h2>
    <i>Per Solange Margot</i>
   
  
    <p class="mt-4">
      <?php echo html_entity_decode($post->contenido_it); ?>

    </p>
      
                

            

            
        

        
  </div>
</section>







<section class="contacto  bg-white">
  
<?php echo $__env->make('includes.footerItaliano', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>



  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appItaliano', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogS\resources\views/italiano/post.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<section class="banner m-0">
    <div class="container-fluid p-0 m-0 banner__cont-principal">
    
    </div>

</section>

<section class="terapias">
    <h2 class="terapias__titulo">terapias <br> holisticas</h2>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogS\resources\views/home.blade.php ENDPATH**/ ?>
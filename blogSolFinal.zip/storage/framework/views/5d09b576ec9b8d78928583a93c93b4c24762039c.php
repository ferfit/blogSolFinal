

<?php $__env->startSection('content'); ?>



<section class="terapias terapias--terapias mt-5">
  <div class="container">

    <img src="/storage/<?php echo e($post->imagen); ?>" class="rounded shadow img-fluid ">
    <h2 class="mt-5"><?php echo e($post->titulo_en); ?></h2>
    <i>For Solange Margot</i>
   
  
    <p class="mt-4">
      <?php echo html_entity_decode($post->contenido_en); ?>

    </p>
      
                

            

            
        

        
  </div>
</section>







<section class="contacto  bg-white">
  
<?php echo $__env->make('includes.footerIngles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>



  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appIngles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogS\resources\views/ingles/post.blade.php ENDPATH**/ ?>
<div>
    <div class="py-5">
        
        <div class="container ">
            

                <input wire:model="search" type="text" placeholder="Buscar..."  class="form-control w-25"/>
  
            <table class="table bg-white mt-2 shadow">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th >Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $this->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="h-auto"><?php echo e(Str::limit (($servicio->titulo),60)); ?></td>
                            
                            <td class="h-auto"><?php echo e(Str::limit (($servicio->descripcion),60)); ?></td>

                            <td class="h-auto">
                                <div class="row">
                                    <a href="" class="btn btn-light  mr-2 mb-1 shadow rounded-pill">Ver</a>
                                    <a href="<?php echo e(route('administracion.servicios.edit', ['servicio'=> $servicio ])); ?>" class="btn btn-primary mr-2 mb-1 shadow rounded-pill">Editar</a>
                                
                                    <form action="<?php echo e(route('administracion.servicios.destroy', $servicio)); ?>" method="POST" class="" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="submit" class="btn btn-danger d-inline mr-1 shadow rounded-pill"
                                            value="Eliminar">
                                    </form>
                                </div>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
         
            <div class="mx-auto">
                <?php echo e($this->results->links()); ?>

            </div>   

        </div>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blogSol\resources\views/livewire/servicio-index.blade.php ENDPATH**/ ?>
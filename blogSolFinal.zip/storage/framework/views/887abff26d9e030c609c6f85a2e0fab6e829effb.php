

<html>

<h2>Mensaje nuevo de tu sitio web:</h2>

<p>nombre: <?php echo e($nombre); ?> </p> 
<p>email:<?php echo e($email); ?></p>
<p>mensaje:<?php echo e($mensaje); ?></p>



</html><?php /**PATH C:\xampp\htdocs\blogSolFinal\blogSolFinal\resources\views/testmail.blade.php ENDPATH**/ ?>
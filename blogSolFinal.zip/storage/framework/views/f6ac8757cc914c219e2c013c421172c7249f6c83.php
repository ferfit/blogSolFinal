

<?php $__env->startSection('metas'); ?>
  <meta name="robots" content="index,follow"/> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner m-0 position-relative" 
data-aos="fade-opacity"
data-aos-duration="1500">

    <div class="container-fluid p-0 m-0 banner__cont-principal">

    <h1 class="banner__titulo"
    data-aos="fade-up"
    data-aos-offset="200"
    data-aos-delay="100"
    data-aos-duration="2000"
    >Solange <br> Margot</h1>

    <h2 class="banner__subtitulo"
    data-aos="fade-up"
    data-aos-offset="0"
    data-aos-delay="800"
    data-aos-duration="2000"
    >Terapeuta Holística</h2>

    <img 
    data-aos="fade-opacity"
    data-aos-duration="3000"
    src="<?php echo e(asset('img/logo.png')); ?>" class="banner__logo" alt="">
    
    </div>

    

</section>


<section class="terapias ">
  <div class="container">

        <div class="row p-0">
            <div class="terapias__cont-titulos col-12 col-md-4"
            data-aos="fade-opacity"
            data-aos-duration="1000"
            >
                
                <h2 class="terapias__titulo-principal">Terapias</h2>
                <p class="terapias__parrafo-principal">
                    Cada propuesta nos invita a bucear en nuestro interior y nos ayuda a
                    descubrir nuevos y beneficiosos hábitos. Tomas de conciencia, nuevas
                    perspectivas, aceptación, integración y sanación, son unas de las infinitas
                    oportunidades que pueden surgir si te aventuras en este Despertar Consciente.
                    Abrazando nuestro pasado podremos integrar la Magia que nos rodea y, de
                    esta manera, materializar nuestros Sueños.
                </p>
            </div>
            <div class="terapias__cont-terapias row mx-auto col-12 col-md-8">


                <?php $__currentLoopData = $terapiasEspañol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terapia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="terapias__cont-terapia col-12 col-md-5 col-lg-5 p-5 p-md-23 p-lg-5 mb-4  mx-sm-1 mx-lg-4 rounded shadow"
                data-aos="fade-up"
                data-aos-duration="1500"
                data-aos-delay="500"
                >
                    <h2 class="terapias__titulo"><?php echo e($terapia->titulo); ?></h2>
                    <h3 class="terapias__subtitulo"><?php echo e($terapia->subtitulo); ?></h3>
                    <p class="terapias__descripcion mt-3">
                    <?php echo e(Str::limit (($terapia->descripcion),300)); ?>

                    </p>
                    <a href="<?php echo e(route('terapias')); ?>" class="text-dark"><span class="terapias__leermas">Leer más...</span></a>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php if( $terapiasTotales->count()>4 ): ?>
              <div class="col-12 d-flex justify-content-center">
                <a href="<?php echo e(route('terapias')); ?>" class=" text-center mt-3 terapias__ver-todas p-2 rounded-pill shadow">Ver todas</a>
              </div>
              <?php endif; ?>

            </div>
        </div>

        
  </div>
</section>


<!-- testimonios -->
<?php echo $__env->make('includes.carrousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- testimonios end -->

<section class="blog">

  <h2 class="blog__titulo-principal text-center mb-3 mr-5"
    data-aos="fade-down"
    data-aos-duration="1500"
    data-aos-delay="100">Blog
  </h2>

  <p class="blog__parrafo-principal text-center mb-5"
    data-aos="fade-opacity"
    data-aos-duration="1500"
    data-aos-delay="300">&quot;Acompáñame a viajar en mis pensamientos, aventuras y sueños
    cumplidos&quot;
  </p>

  <div class="container">
    <div class="row d-flex justify-content-center p-3">

      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="blog__cont-post col-12 col-md-3 m-2 p-4 rounded h-auto shadow"
        data-aos="fade-up"
        data-aos-duration="1500"
        data-aos-delay="100">

        <h3 class="blog__titulo"><?php echo e(Str::limit (($post->titulo),25)); ?></h3>
        <p class="blog__parrafo"><?php echo Str::limit ( html_entity_decode($post->contenido),200); ?></p>
        <a href="<?php echo e(route('post',$post)); ?> " ><span class="terapias__leermas text-dark">Leer más...</span></a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

      

      <div class="col-12 d-flex justify-content-center" data-aos="fade-opacity"
      data-aos-duration="1500"
        data-aos-delay="100">
        <a href="" class="blog__ver-todos mt-5 text-center rounded-pill shadow">Ver todos</a>
      </div>

    </div>

        
  </div>

  

    
    
</section>



<?php if( session('formulario') ): ?>
 <script>Swal.fire('Su mensaje se ha enviado exitosamente.')</script>
<?php endif; ?>






<section class="contacto  bg-white" id="contacto">
  <div class="container">
    <div class="row p-3">

      <div class=" col-12 col-md-6
      contacto__cont-titulos d-flex flex-column justify-content-center align-items-center">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" class="w-25">
        
        <h2 class="text-center my-3">“Recorramos juntos el Camino!”</h2>
        <h3 class="text-center mb-2">¿Quieres hacerme alguna consulta?</h3> 
        <p class="text-center">
          Podes enviar tu mensaje a través del siguiente <br> formulario y lo
          contestaré a la brevedad.
        </p> 
      </div>

      <div class="col-12 col-md-6 
      contacto__cont-formulario rounded shadow-lg">

      <form method="POST" action="<?php echo e(route('form')); ?>" novalidate>
                <?php echo csrf_field(); ?>

                

                <div class="form-group ">
                    <label for="nombre">Nombre </label>
                    <input type="text" 
                    name="nombre" 
                    class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombre"
                        value="">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group ">
                    <label for="email">Email</label>
                    <input type="email" 
                    name="email" 
                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                        value="">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="form-group">
                    <label for="mensaje">Mensaje</label>
                    <br>
                    <textarea name="mensaje" id="mensaje" cols="30" rows="10" class="form-control"></textarea>
                    <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               

                <div class="form-group">
                    <input type="submit" class="btn btn-white contacto__boton-enviar shadow rounded" value="Enviar">
                </div>


            </form>
      
      </div>
    
    </div>

  </div>

  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>



  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogSolFinal\blogSolFinal\resources\views/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">
    <h1 class="tart">Listado de publicaciones</h1>
</div>

<div class="container mt-2 ">
    <a href="<?php echo e(route('administracion.posts.create' )); ?>" class="btn btn-success shadow">Crear publicación</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post-index')->html();
} elseif ($_instance->childHasBeenRendered('qGtS8Kf')) {
    $componentId = $_instance->getRenderedChildComponentId('qGtS8Kf');
    $componentTag = $_instance->getRenderedChildComponentTagName('qGtS8Kf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qGtS8Kf');
} else {
    $response = \Livewire\Livewire::mount('post-index');
    $html = $response->html();
    $_instance->logRenderedChild('qGtS8Kf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogSol\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>
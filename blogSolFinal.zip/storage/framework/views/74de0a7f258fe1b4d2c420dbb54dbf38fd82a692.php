

<?php $__env->startSection('content'); ?>
<section class="banner m-0" 
data-aos="fade-opacity"
data-aos-duration="1500">

    <div class="container-fluid p-0 m-0 banner__cont-principal banner__cont-principal--terapias">

    <h1 class="banner__titulo"
    data-aos="fade-up"
    data-aos-offset="200"
    data-aos-delay="100"
    data-aos-duration="2000"
    >Terapias</h1>
    
    </div>

</section>


<section class="terapias terapias--terapias">
  <div class="container">

        

        

        

            <?php $__currentLoopData = $terapiasEspañol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terapia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="terapias__cont-terapia  row rounded p-3 shadow mt-3"
                data-aos="fade-up"
                data-aos-duration="1500"
                data-aos-delay="500"
                >
                    <div class="col-12 col-md-4 terapias__cont-imagen overflow-hidden rounded shadow p-0">
                        <img src="/storage/<?php echo e($terapia->imagen); ?>" alt="" class="h-100" >
                    </div>
                    

                    <div class="col-12 col-md-8 p-3 ">
                        <h2 class="terapias__titulo mt-4"><?php echo e($terapia->titulo); ?></h2>
                        <h3 class="terapias__subtitulo"><?php echo e($terapia->subtitulo); ?></h3>
                        <p class="terapias__descripcion mt-3">
                        <?php echo e($terapia->descripcion); ?>

                        </p>
                        <span class="terapias__leermas">EU <?php echo e($terapia->precioEuro); ?></span><br><br>
                        <span class="terapias__leermas">ARS <?php echo e($terapia->precioPeso); ?></span>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        

        
  </div>
</section>







<section class="contacto  bg-white">
  
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>



  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogSolFinal\blogSolFinal\resources\views/terapias.blade.php ENDPATH**/ ?>
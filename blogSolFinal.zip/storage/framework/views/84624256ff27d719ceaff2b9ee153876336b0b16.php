

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">
    <h1 class="tart">Listado de servicios</h1>
</div>

<div class="container mt-2 ">
    <a href="<?php echo e(route('administracion.servicios.create' )); ?>" class="btn btn-success shadow">Crear servicio</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('servicio-index')->html();
} elseif ($_instance->childHasBeenRendered('R6crneW')) {
    $componentId = $_instance->getRenderedChildComponentId('R6crneW');
    $componentTag = $_instance->getRenderedChildComponentTagName('R6crneW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R6crneW');
} else {
    $response = \Livewire\Livewire::mount('servicio-index');
    $html = $response->html();
    $_instance->logRenderedChild('R6crneW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogSol\resources\views/admin/servicios/index.blade.php ENDPATH**/ ?>
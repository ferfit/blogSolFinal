@extends('layouts.app')

@section('content')
<section class="banner m-0">
    <div class="container-fluid p-0 m-0 banner__cont-principal">
    
    </div>

</section>

<section class="terapias">
    <h2 class="terapias__titulo">terapias <br> holisticas</h2>
</section>

@endsection

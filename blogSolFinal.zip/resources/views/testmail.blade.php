

<html>

<h2>Mensaje nuevo de tu sitio web:</h2>

<p>nombre: {{$nombre}} </p> 
<p>email:{{$email}}</p>
<p>mensaje:{{$mensaje}}</p>



</html>
<footer class="footer mt-5">
  <div class="footer__linea"></div>
  <div class="container d-flex justify-content-center">
      <p class="p-0 m-0 p-2 text-center">© Diritto d'autore <script>document.write(new Date().getFullYear());</script> <a class="footer__copy"href="https://tuproyectoweb.com.ar" target="_blank">Tu Proyecto Web</a>. Tutti i diritti riservati.</p>
  </div>
 </footer>